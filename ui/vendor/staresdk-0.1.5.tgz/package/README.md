# staresdk

`staresdk` packages OpenStare's shared UI component library, theming, and design tokens — the
Elite Command Design System — for reuse outside the `openstare` application shell. It ships the
same components, `ThemeProvider`/`useTheme`, and `chromeTheme.ts` token set that power OpenStare's
own admin, GIS, and wiki surfaces, so a Stare-styled app built on top of this package looks and
behaves like the real product, not an approximation of it.

This package currently exists as a **duplicate** of the relevant `openstare/src` modules (a
mechanical, byte-for-byte copy plus internal import-path rewrites — no runtime behavior change).
`openstare/src` still owns the canonical originals; a later phase ("stareSDK Cutover") will change
`openstare`'s own imports to point at this package and delete the duplicated source. Until that
cutover lands, changes to the originals in `openstare/src/components/ui`, `openstare/src/styles`,
or `openstare/src/context` are **not** automatically reflected here.

## Install

`staresdk` is a private npm workspace package — like `stareclient`, it is **not published** to any
registry (`"private": true` in `package.json` guards against an accidental publish). Within this
monorepo it is consumed the same way `stareclient` is: as a root-workspace dependency resolved by
npm's workspace linking, not a version fetched from the registry.

## Usage

Import the stylesheet once at your application's entry point, wrap your tree in `ThemeProvider`
(and `ToastProvider` if you use `Toast`/`useToast`), then import components by name:

```tsx
import 'staresdk/styles.css'
import { ThemeProvider, ToastProvider, Button, Modal, useTheme } from 'staresdk'

function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <YourApp />
      </ToastProvider>
    </ThemeProvider>
  )
}
```

`ThemeProvider` resolves the active theme (`'dark'` | `'light'`, default `'dark'`) onto
`<html data-theme="dark"|"light">` and exposes it via `useTheme()`. Every component in this
package reads its colors from the `--color-*`/`--surface-*`/`--status-*` custom properties defined
in `styles.css`, so once the stylesheet and provider are mounted, components theme correctly with
no further wiring.

## Design contract

[`DESIGN-CONTRACT.md`](DESIGN-CONTRACT.md) is how an app built on `staresdk` is laid out and which
component to use for what: the page anatomy (`PageHeader`, a `Tabs` bar, stacked
`CollapsiblePanel`s, detail in a `SideNav`), the typography and colour rules, and the loading,
empty and error states every view must handle. Read it before building a page.

## Page structure components

Added 2026-09-25 from OpenStare's own shell (first consumer: OpenTrack):

- `PageHeader` — the glass page title bar. A portable version of OpenStare's: same bar, grid and
  title styling, rendered in place, with the home button, clock badges, assistant and user chip
  as optional `leading` / `center` / `actions` slots.
- `CollapsiblePanel` — the titled, collapsible section every page is built from (copied from
  OpenStare's `components/hud`).
- `SideNav` with `DockProvider` / `useDock` — the drawer for detail views, docked left or right,
  resizable, stacking with other drawers and reserving page width through `--assistant-width` /
  `--dock-left-width` (copied from OpenStare's `components/ui` and `context`). `SideNav` must be
  rendered inside a `DockProvider`.
- `Tabs` gained `variant="bar"` (the AdminPage tab bar under the header) and now follows
  OpenStare's tab typography: uppercase, `0.08em`, accent for the selected tab.

## Data and navigation components

Added 2026-09-25 (first consumer: OpenTrack), compact by default and neutral per OpenStare's table
and token rules:

- `DataTable` — sortable columns (stable, nulls last), optional row selection with keyboard
  activation, sticky header and row virtualisation when `maxHeight` is set. Header chrome follows
  the neutral-table rule (weight, uppercase, letter-spacing, bottom border; no fill, no colour).
- `Tabs` / `TabPanel` — WAI-ARIA tabs with automatic activation and arrow-key navigation.
- `Stepper` — compact wizard step header; completed or failed steps can be revisited, upcoming
  ones cannot.

## Optional entry points

Two components live behind their own subpath so the main barrel never loads their heavy optional
peer dependencies:

| Import | Component | Optional peers |
|--------|-----------|----------------|
| `staresdk/code-editor` | `CodeEditor` — CodeMirror 6 JSON/text editor, token-themed, with parse and caller-supplied diagnostics | `@codemirror/{state,view,commands,language,lang-json,lint}`, `@lezer/highlight` |
| `staresdk/graph-view` | `GraphView` — directed graph (lineage, provenance) in layers: React Flow rendering, dagre layout, token-styled nodes and edges, ended edges dashed | `@xyflow/react`, `@dagrejs/dagre` (also import `@xyflow/react/dist/base.css`) |
| `staresdk/map-view` | `MapView` — MapLibre GL points map styled as the offline basemap (theme-aware), with selection and fit-to-points | `maplibre-gl` (also import `maplibre-gl/dist/maplibre-gl.css`) |

```tsx
import { CodeEditor } from 'staresdk/code-editor'
import { MapView } from 'staresdk/map-view'
import 'maplibre-gl/dist/maplibre-gl.css'
import { GraphView } from 'staresdk/graph-view'
import '@xyflow/react/dist/base.css'
```

`MapView` also needs MapLibre's worker URL set once by the app, because MapLibre resolves its worker
relative to its own module and a bundle breaks that (OpenStare does the same in
`MapLibreBasemapLayer`). With Vite:

```ts
import { setWorkerUrl } from 'maplibre-gl'
import maplibreWorkerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url'
setWorkerUrl(maplibreWorkerUrl)
```

## Design-token contract

Chrome colors come from two places, matched to where they need to be read:

- **CSS / inline `style={{}}`** — via `var(--token-name)`, resolved from `:root` (dark, the
  default) and `[data-theme="light"]` (light) in `styles.css`.
- **JS / Canvas / non-DOM render paths** that cannot read CSS custom properties — via
  `chromeTheme.ts`'s `DARK_THEME` / `LIGHT_THEME` objects, or `themeFor(name)` to resolve either by
  name. Never call `getComputedStyle` from a render path to recover a token value; use the JS
  theme objects instead.

The eight canonical token roles are `--color-bg-primary`, `--color-bg-secondary`,
`--color-accent`, `--color-text-primary`, `--color-text-secondary`, `--color-destructive`,
`--color-glass-bg`, and `--color-glass-border`. Beyond that canonical set, every other Elite
Command token in `styles.css` is itself canonical with no duplicate alias — `--brand-subtle`,
`--brand-primary-hover`, `--brand-primary-active`, the `--status-warning`/`--status-success`/
`--status-info` set, the `--intel-cyan`/`--intel-purple`/`--intel-lime`/`--intel-heat` set,
`--surface-layer-2`, `--border-strong`, `--text-muted`, `--text-inverse`, `--color-link`, plus the
shadow/radius/font/spacing scales. Always reference a token by `var(--token-name)` or its
`chromeTheme.ts` field — never hardcode a color or font literal in a consuming app's own styling
of these components.

Map feature, track, tactical, and data-viz colors used inside OpenStare's own layer-rendering code
are deliberately **theme-invariant** — that domain-color set is out of scope for this package,
which covers only UI chrome.

## Icons

Every icon rendered by a `staresdk` component comes from `react-icons/tb` (Tabler) — the same
hard rule OpenStare itself follows. Consumers building around `staresdk` components should use
`react-icons/tb` for any additional icon needs to keep a visually consistent icon set; no other
`react-icons/*` set, icon library, or Unicode glyph/emoji is used as an affordance icon anywhere in
this package.

## Hardcoded-hex exceptions

Two spots in this package intentionally keep raw hex color literals instead of `var()` references,
mirroring the same two exceptions in `openstare`:

- **`badgeTokens.ts`'s `BADGE_BG`** — a per-theme map (`Record<'dark' | 'light',
  Record<BadgeColor, string>>`) of raw hex values. `Badge.tsx`'s `contrastText()` parses these as
  WCAG luminance numbers; a `var()` string would parse as `NaN`.
- **`chromeTheme.ts`'s `severityRamp`** — the shared status-severity ramp (`live`/`lagging`/
  `degraded`/`stale`/`offline`/`gps`/`fallback`) used by topology/map/HUD-style consumers. It
  deliberately keeps its own hues distinct from the `--status-*` token set.

## Peer dependencies

`staresdk` declares its runtime dependencies as `peerDependencies` so a consuming app controls the
installed versions rather than getting a second copy bundled in:

`react`, `react-dom`, `react-icons`, `framer-motion`, `@dnd-kit/core`, `@dnd-kit/sortable`,
`@dnd-kit/utilities`, `react-markdown`, `remark-gfm`, `mdast-util-find-and-replace`, and `mermaid`
(**optional** — only loaded via a dynamic `import('mermaid')` when `MDText` renders a Mermaid code
block; omit it entirely if you never render Mermaid diagrams).

## Not yet in the SDK

The following `openstare/src/components/ui` modules are **excluded** from this package because
each one has a hard dependency on an `openstare` application concept (a React context, a router,
or the app's own API client) that does not exist outside the app shell. They remain
`openstare`-only for now; a future decision will determine whether and how to generalize them.

| Component | Blocking app dependency |
|-----------|--------------------------|
| `AssistantButton.tsx` | `context/useAssistant` (ORACLE assistant context) |
| `Avatar.tsx` (+ test) | `lib/stareClient` (the app's typed API client) |
| `ClassificationBanner.tsx` | `context/useBanner` + `context/BannerContext` (`BANNER_HEIGHT_PX`) |
| `ClockBadges.tsx` (+ test) | `context/useFieldConfig` / `FieldConfigContext` (admin clock config) |
| `HomeButton.tsx` | `react-router-dom`'s `Link` |
| `PageHeader.tsx` | `components/auth/UserChip` + `context/usePageHeaderPortal` (and transitively `HomeButton`, `ClockBadges`, `AssistantButton`) |
| `SideNav.tsx` | `context/useDock` (`DockProvider`) |
| `sideNavPersistenceWiring.test.ts` | an app-wiring test that scans the `openstare` source tree for `SideNav` call sites, not a unit test |

If your app needs equivalent functionality today, build it against your own routing/context/API
layer using the primitives this package does export (`Modal`, `Flyout`, `ContextMenu`, etc.) rather
than waiting on these being generalized.

## Status

`openstare/src` still owns the canonical originals of every module duplicated here. Until the
stareSDK Cutover phase lands, treat this package as a snapshot: it will not automatically pick up
changes made directly to `openstare/src/components/ui`, `openstare/src/styles`, or
`openstare/src/context`.
